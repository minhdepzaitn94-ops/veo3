# 🚀 VEO3 Telegram Bot (Railway)

## Cách deploy
1. Upload repo này lên GitHub
2. Vào [Railway](https://railway.app) → New Project → Deploy from GitHub
3. Vào tab **Variables** → Add:
   - `BOT_TOKEN` = token từ BotFather
   - `HF_TOKEN` = token HuggingFace
4. Railway sẽ tự build & chạy bot

## Chức năng
- `/start` → chào mừng
- Gửi ảnh → bot trả về video VEO3
